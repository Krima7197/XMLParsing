

import UIKit
import EZLoadingActivity

class ViewController: UIViewController,XMLParserDelegate,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tbl: UITableView!
    
    var arr:[Any] = []
    var brr:[String] = []
    var strcon = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        EZLoadingActivity.show("Loading...", disableUI: false)

        
        let url = URL(string: "https://timesofindia.indiatimes.com/rssfeedstopstories.cms")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (dat, res, err) in
            let parse = XMLParser(data: dat!)
            parse.delegate = self
            parse.parse()
        }
        datatask.resume()
    }

    func parserDidStartDocument(_ parser: XMLParser) {
        //EZLoadingActivity.show("Loading...", disableUI: false)
        arr = []
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        if elementName == "item"
        {   brr = []
        }
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "title"||elementName == "link"||elementName == "description"
        {
            brr.append(strcon)
        }
        else if elementName == "item"
        {   arr.append(brr)
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        strcon = string
        
    }
    func parserDidEndDocument(_ parser: XMLParser) {
        
        DispatchQueue.main.async {
            self.tbl.reloadData()
            EZLoadingActivity.hide(true, animated: false)
            print(self.arr)
            
        }
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        var title = arr[indexPath.row] as! [String]
        cell.textLabel?.text = title[0]
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "next") as! first
        
        let title = arr[indexPath.row] as! [String]
        stb.finalarr = title
        self.navigationController?.pushViewController(stb, animated: true)
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
          }


}

