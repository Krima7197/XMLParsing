

import UIKit
import EZLoadingActivity

class first: UIViewController,UIWebViewDelegate {
    var finalarr:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        txtv.text = finalarr[1]
        let str = finalarr[2]
        let url = URL(string: str)
        EZLoadingActivity.Settings.SuccessColor = UIColor.green
        EZLoadingActivity.show("Fetching data...", disableUI: true)
        web.loadRequest(URLRequest.init(url: url!))
    }
    func webViewDidFinishLoad(_ webView: UIWebView) {
        EZLoadingActivity.hide(true, animated: false)

    }
    @IBOutlet weak var web: UIWebView!
    @IBOutlet weak var txtv: UITextView!

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    

    }
